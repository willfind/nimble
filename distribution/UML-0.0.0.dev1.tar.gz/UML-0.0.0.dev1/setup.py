from setuptools import setup, find_packages, Extension
from distutils.command.sdist import sdist as _sdist
import os, glob

# command line: python setup.py sdist

cmdclass = {}

# only include directories that do not utilize the inspect module,
# which does not work for cython
# TODO remove one instance of inspect in UML/data/base.py
to_cythonize = [os.path.join('UML', '*.py'),
                os.path.join('UML', 'data', '*.py')]
exclude = [os.path.join('UML', 'uml.py'),
           os.path.join('UML/__init__.py'),
           os.path.join('UML/data/__init__.py'), # uses inspect
           os.path.join('UML/data/dataHelpers.py'), # bug in python2
           ]

# Make sure the compiled Cython files in the distribution are up-to-date
class sdist(_sdist):
    def run(self):
        from Cython.Build import cythonize, build_ext
        cythonize(to_cythonize, exclude=exclude,
                  compiler_directives={'always_allow_keywords': True},
                  exclude_failures=True,)
        cmdclass['build_ext'] = build_ext
        _sdist.run(self)
cmdclass['sdist'] = sdist

# paths based on running from top-level directory
umlC = glob.glob(os.path.join('UML', '*.c'))
dataC = glob.glob(os.path.join('UML', 'data', '*.c'))

allExtensions = umlC + dataC
extensions = []
for extension in allExtensions:
    # name convention dir.subdir.filename
    name = ".".join(extension[:-2].split("/"))
    extensions.append(Extension(name, [extension]))

setup(
    name='UML',
    version='0.0.0.dev1',
    packages=find_packages(exclude=['*.tests',
                                    '*.examples*']),
    install_requires=['six>=1.5.1',
                      'future>=0.11.4',
                      'numpy>=1.10.4',
                     ],
    ext_modules = extensions,
    cmdclass = cmdclass,
    )


## source distribution and universal binary distribution w/ pure Python

# import setuptools

# #command line: python setup.py sdist bdist_wheel --universal

# setuptools.setup(
#     name="UML",
#     version="0.0.0.dev1"
#     packages=setuptools.find_packages(exclude=['*.tests',
#                                                '*.examples*']),
#     install_requires=['six>=1.5.1',
#                       'future>=0.11.4',
#                       'numpy>=1.10.4',
#                      ],
#     )

    ## additional metadata TODO

    # with open("README.md", "r") as fh:
    #     long_description = fh.read()

    # author="Example Author",
    # author_email="author@example.com",
    # description="A small example package",
    # long_description=long_description,
    # long_description_content_type="text/markdown",
    # url="https://github.com/pypa/example-project",
    # classifiers=(
    #     'Development Status :: 3 - Alpha',
    #     'Programming Language :: Python :: 2',
    #     'Programming Language :: Python :: 2.7',
    #     'Programming Language :: Python :: 3',
    #     'Programming Language :: Python :: 3.4',
    #     'Programming Language :: Python :: 3.5',
    #     'Programming Language :: Python :: 3.6',
    #     'Operating System :: OS Independent')


## Cython
# from __future__ import absolute_import
# from distutils.core import setup
# from Cython.Build import cythonize
# import os
#
# setup(ext_modules = cythonize(["UML/data/*.py", "UML/helpers.py"],
#                               exclude=["UML/data/dataHelpers.py", "UML/data/__init__.py"],
#                               compiler_directives={'always_allow_keywords': True}))






# name = 'UML'
# version = '0.0.0.dev1'
# packages=setuptools.find_packages(exclude=['*.tests',
#                                           '*.examples*'])
# install_requires=['six>=1.5.1',
#                   'future>=0.11.4',
#                   'numpy>=1.10.4',
#                  ]
# try:
#     from Cython.Build import cythonize
#     extensions = cythonize(["UML/data/*.py", "UML/helpers.py"],
#                             exclude=["UML/data/dataHelpers.py", "UML/data/__init__.py"],
#                             compiler_directives={'always_allow_keywords': True})
#     setuptools.setup(
#         name=name,
#         version=version,
#         packages=packages,
#         install_requires=install_requires,
#         ext_modules = extensions
#         )
# except ImportError:
#     setuptools.setup(
#         name=name,
#         version=version,
#         packages=packages,
#         install_requires=install_requires,
#         )
