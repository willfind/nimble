"""
Intentionally empty; this is a standin file which is necessary to display that
UML/runTests.py correctly does test selection of interfaces whose underlying
packages are missing.

"""
